## Lab 6 - Fragments and Navigation Lab

This is the starter code for lab 6, see [Android University Course - Lab 6](https://courses.codepath.org/courses/android_university/unit/6#!exercises) for additional instructions.


