package com.codepath.nytimes.ui.books;

import com.codepath.nytimes.models.BestSellerBook;

public interface OnListFragmentInteractionListener {

    void onItemClick(BestSellerBook item);
}
