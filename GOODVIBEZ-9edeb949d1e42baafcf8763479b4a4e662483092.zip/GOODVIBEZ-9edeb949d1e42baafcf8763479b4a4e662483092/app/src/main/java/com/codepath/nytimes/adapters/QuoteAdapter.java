package com.codepath.nytimes.adapters;

import androidx.recyclerview.widget.RecyclerView;

//public class QuoteAdapter extends RecyclerView.Adapter<BookAdapter.ViewHolder> {
//}
